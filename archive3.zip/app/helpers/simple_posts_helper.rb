module SimplePostsHelper
end
