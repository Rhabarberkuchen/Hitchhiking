module BasicPagesHelper
end
