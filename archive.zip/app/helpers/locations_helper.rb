module LocationsHelper
end
